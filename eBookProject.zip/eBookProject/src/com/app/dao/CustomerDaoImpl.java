package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Book;
import com.app.pojos.User;

@Repository
public class CustomerDaoImpl implements ICustomerDao {

	@Autowired
	private SessionFactory sf;
	@Override
	public List<User> showAllCustomer() {
		String query="select u from User u where u.role=:rl";
		return sf.getCurrentSession().createQuery(query,User.class).setParameter("rl", "customer").getResultList();
	}
	@Override
	public List<User> showAllCustomer1() {
		String query="select u from User u where u.role=:rl or u.role=:rm";
		return sf.getCurrentSession().createQuery(query,User.class).setParameter("rl", "customer").setParameter("rm", "admin").getResultList();
	
	}
	
	@Override
	public String removerCustomer(int uid) {
		
		String query="select u from User u where u.id=:uid";

		User c=sf.getCurrentSession().createQuery(query,User.class).setParameter(
					  "uid", uid).getSingleResult();
		
		
		    sf.getCurrentSession().delete(c);
		return "Customer data removed from database successfully";
	}

}
