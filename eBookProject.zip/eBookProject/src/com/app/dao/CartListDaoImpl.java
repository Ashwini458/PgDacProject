package com.app.dao;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.app.pojos.Cart;

@Repository
public class CartListDaoImpl implements ICartListDao {

	@Autowired
	private SessionFactory sf;
	@Override
	public List<Cart> cartList(int uid) {
		String query="select u from Cart u where u.uid=:rl";
		return sf.getCurrentSession().createQuery(query,Cart.class).setParameter("rl", uid).getResultList();
	}

}
