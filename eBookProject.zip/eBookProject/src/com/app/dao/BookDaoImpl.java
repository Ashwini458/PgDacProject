package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Book;
import com.app.pojos.Cart;
import com.app.pojos.Order;

@Repository
public class BookDaoImpl implements IBookDao {
    @Autowired
	private SessionFactory sf;
	@Override
	public List<Book> showAllBookList() {
		String jpql="select b from Book b";
		return sf.getCurrentSession().createQuery(jpql,Book.class).getResultList();
	}

	
	@Override 
	public String addBook(Book b)
	{
		System.out.println("In dao Add to book");
		sf.getCurrentSession().save(b);
		String msg="Book added successfully";
		msg="Adding book successfull, ID :"+b.getB_id();
		return msg;
	}
	@Override
	public String removeBook(int bid) {
		String query="select u from Book u where u.b_id=:bid";

		Book c=sf.getCurrentSession().createQuery(query,Book.class).setParameter(
					  "bid", bid).getSingleResult();
		
		
		    sf.getCurrentSession().delete(c);
		return "Book deleted from database successfully";
	}
	
	  @Override
	  public String buyBook(int bid,int uid) { 
		  String query="select u from Cart u where u.b_id=:bid and u.uid=:uid";
	  
	  Cart c=sf.getCurrentSession().createQuery(query,Cart.class).setParameter(
	  "bid", bid).setParameter("uid", uid).getSingleResult(); 
	  int bookId=c.getB_id(); 
	  String name=c.getName(); 
	  double price=c.getPrice();
	  int oid=1;
	  Order order=new Order(oid,bookId,name,price,uid);
	  System.out.println("book ID"+bookId+"name"+name+"price"+price+"uid"+uid);
	  sf.getCurrentSession().save(order); 
	  return "Book added to order list.."; 
	  }
	  
	  
	  @Override
	  public List<Order> showOrderList(int bid,int uid) { 
		  String jpql="select b from Order b where b.uid=uid"; return
	  sf.getCurrentSession().createQuery(jpql,Order.class).getResultList();
	  
	  }
	  @Override
	public List<Cart> order() {
		  String jpql="select b from Cart b ";
		  return sf.getCurrentSession().createQuery(jpql,Cart.class).getResultList();
		}
		
	
	 
}
