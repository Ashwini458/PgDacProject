package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.User;

@Repository
public class UserDaoImpl implements IUserDao {

	@Autowired
	private SessionFactory sf;
	
	@Override
	public User authenticateUser(String email, String pass) {
		System.out.println("In dao layer Authenticate User");
		String jpql="select u from User u where u.email=:em and u.password=:pa";
		return sf.getCurrentSession().createQuery(jpql,User.class).setParameter("em", email).setParameter("pa", pass)
				.getSingleResult();
	}

@Override
	public String signUp(User u) {
		System.out.println("in User Dao:signUp");
		
		sf.getCurrentSession().save(u);
		String msg="Hi "+u.getName()+" You signed up successfully";
		
		return msg;
		
	}
	
		
	
}
