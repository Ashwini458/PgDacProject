package com.app.dao;

import com.app.pojos.Cart;

public interface ICartDao {
Cart addToCart(int b_id,int uid);

String deleteFromCart(int bid, int uid);
}
