package com.app.dao;

import java.util.List;

import com.app.pojos.User;

public interface ICustomerDao {
	List<User> showAllCustomer();

	List<User> showAllCustomer1();
	
	String removerCustomer(int bid);
}
