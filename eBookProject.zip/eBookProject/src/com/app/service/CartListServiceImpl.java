package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ICartListDao;
import com.app.pojos.Cart;

@Service
@Transactional
public class CartListServiceImpl implements ICartListService {
@Autowired
private ICartListDao dao;
	@Override
	public List<Cart> cartList(int uid) {
		
		return dao.cartList(uid);
	}

}
