package com.app.service;

import java.util.List;



import com.app.pojos.User;

public interface ICustomerService {
 List<User> showAllCustomer();
 List<User> showAllCustomer1();
 String removeCustomer(int uid);
}
