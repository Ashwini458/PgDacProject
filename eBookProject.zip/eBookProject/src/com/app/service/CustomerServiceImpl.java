package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ICustomerDao;
import com.app.pojos.User;


@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	private ICustomerDao dao;

	@Override
	public List<User> showAllCustomer() {
		
		return dao.showAllCustomer();
	}
@Override
public List<User> showAllCustomer1() {
	
	return dao.showAllCustomer1();
}
@Override
public String removeCustomer(int uid) {
	
	return dao.removerCustomer(uid);
}
}
