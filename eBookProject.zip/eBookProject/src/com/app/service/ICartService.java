package com.app.service;
import com.app.pojos.Cart;

public interface ICartService {
	Cart addToCart(int bid,int uid);

	String deleteFromCart(int bid, int uid);
}
