package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="cart")
public class Cart {
//id,name,author,stream,year,price,
	
	
	  @Id
	  
	  @GeneratedValue(strategy = GenerationType.IDENTITY) 
	  private int c_id;
	 
	
	
	private int b_id;
	
	@Column(length = 30)
	private String name;
	
	private int uid;
	
	private double price;
	
	/*
	 * @OneToMany(mappedBy = "cartid") private List<Book>books;
	 */
	public Cart() {
		System.out.println("In def constr of cart..");
	}

	

	public Cart(int b_id,  String name, double price,int uid) {
		super();
		this.b_id = b_id;
		
		this.name = name;
		this.price = price;
		this.uid=uid;
	}
	



	public int getUid() {
		return uid;
	}



	public void setUid(int uid) {
		this.uid = uid;
	}



	/*
	 * public List<Book> getBooks() { return books; }
	 * 
	 * 
	 * 
	 * public void setBooks(List<Book> books) { this.books = books; }
	 */



	public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}

	public int getB_id() {
		return b_id;
	}

	public void setB_id(int b_id) {
		this.b_id = b_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Cart [c_id=" + c_id + ", b_id=" + b_id + ", name=" + name + ", price=" + price + "]";
	}

		
	
	
}
