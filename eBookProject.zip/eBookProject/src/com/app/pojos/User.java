package com.app.pojos;



import javax.persistence.*;

@Entity
@Table(name="user")
public class User {
   
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(length = 30)
	private String name;
	
	@Column(length = 30)
	private String email;
	
	@Column(length = 30)
	private String password;
	
	@Column(length = 30)
	private String city;
	
	@Column(length = 10)
	private String contactNo;
	
	
	
	private String role;
	
	public User() {
		System.out.println("In User Constructor");
	}

	public User( String name, String email, String password, String city, String contactNo, String role) {
		super();
		//this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.city = city;
		this.contactNo = contactNo;
		this.role = role;
	}
	

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", city=" + city
				+ ", contactNo=" + contactNo + ", role=" + role + "]";
	}

	
}
