package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.service.ICartListService;

@Controller
@RequestMapping("/cart")
public class CartController {
	@Autowired
	private ICartListService service;
 public CartController() {
	System.out.println("in constructor of"+getClass().getName());
}
 
 @GetMapping("/save")
 public String addedToCart()
 {
		 System.out.println("save to cart");
	 return "/book/list";
 }
 @GetMapping("/list")
 public String cartList(@RequestParam int uid,Model map,HttpSession hs)
 {
	 hs.setAttribute("cartList", service.cartList(uid));
	 return "/customer/cart";
 }
 
 @GetMapping("/list1")
 public String cartList1(@RequestParam int uid,Model map,HttpSession hs)
 {
	 hs.setAttribute("cartList", service.cartList(uid));
	 return "/customer/cart";
 }
 
}
