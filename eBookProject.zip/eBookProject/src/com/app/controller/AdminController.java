package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Book;
import com.app.service.IBookService;
import com.app.service.ICustomerService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired 
	private IBookService bookService;
	 	 @Autowired
	 	 private ICustomerService service;
    public AdminController() {
	System.out.println("In constructor of "+getClass().getName());
    }

@GetMapping("/list")
public String showAdminPage()
{
	System.out.println("In show admin Page");
	return "/admin/adminPage";
}
	@GetMapping("/removeBook")
	public String removeBook(@RequestParam int bid,HttpSession hs,Model map)
	{
		map.addAttribute("bookRemoved", bookService.removeBook(bid));
		return "redirect:/book/listAdmin";
	}
	@GetMapping("/addBook")
	public String addBookForm()
	{
		System.out.println("IN add book");
		return "/book/add";
	}

	@PostMapping("/addBook")
	public String processAddBook(HttpServletRequest req,HttpServletResponse res,HttpSession hs)
	{
		System.out.println("In process add book");
		//int id=Integer.parseInt(req.getParameter("bookId"));
		String name=(req.getParameter("name"));
		String author=(req.getParameter("author"));
		String stream=(req.getParameter("stream"));
		String year=(req.getParameter("year"));
		double price=Double.parseDouble(req.getParameter("price"));
		Book b=new Book(1,name,author,stream,year,price);
		hs.setAttribute("status", bookService.addBook(b));
		System.out.println("After adding book");
		return "redirect:/book/listAdmin";
	}
	@GetMapping("/orderReport")
	public String orderReport(HttpSession hs)
	{
		hs.setAttribute("order", bookService.order());
		hs.setAttribute("user", service.showAllCustomer());
		return "/admin/order";
	}


}
