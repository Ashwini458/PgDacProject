package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.User;
import com.app.service.IUserService;

@Controller
@RequestMapping("/user")
public class UserController {
	 
	@Autowired
	private IUserService service;
	 
	
	public UserController() {
		System.out.println("In constructor of"+getClass().getName());
	}
	
	@GetMapping("/login")
	public String showLoginPage()
	{
		System.out.println("In show login page");
		return "/user/login"; 
	}
	
	@PostMapping("/login")
	public String processLoginForm(@RequestParam String email,@RequestParam String password,HttpSession hs)
	{
		
		hs.getId();
		System.out.println("Current user id is::"+hs.getId());
		//hs.setAttribute("userId", user.getId());
		System.out.println("In process login form");
		//map.addAttribute("user_details",em+":"+pa);
		try {
			User authenticateUser = service.authenticateUser(email, password);
		hs.setAttribute("user_details", authenticateUser);
		//map.addAttribute("mesg","Login successfull");
		hs.setAttribute("userId", authenticateUser.getId());
		if(authenticateUser.getRole().equals("admin"))
			return "redirect:/admin/list";//create AdminController : add req mapping
		//vendor : logged in
		return "redirect:/customer/details";
		//return "redirect:/customer/details";
	         }catch (RuntimeException e) {
		//e.printStackTrace();
		System.out.println("Error in controller"+e);
		hs.setAttribute("mesg","Invalid Login , Pls retry");
		return "/user/login";
	   }
	}
	@GetMapping("/logout")
	public String showLogoutPage(Model map,HttpSession hs,HttpServletRequest request,HttpServletResponse response)
	{
		map.addAttribute("user_details",hs.getAttribute("user_details"));
		System.out.println("In Logout page");
		hs.invalidate();
		response.setHeader("refresh", "1;url="  +request.getContextPath());
		return "/user/logout";
	}
	@GetMapping("/signup")
	public String signupUserForm()
	{
		System.out.println("In User signup form");
        return "/user/signup";
	}
	
	@PostMapping("/signup")
	public String processSignUpUser(HttpServletRequest req,HttpServletResponse res,HttpSession hs)
	{
		System.out.println("IN processSignUpUser");
		
		
		//int id=Integer.parseInt(req.getParameter("id"));
		String name=(req.getParameter("name"));
		String email=(req.getParameter("email"));
		String password=(req.getParameter("password"));
		String city=(req.getParameter("city"));
		String contactNo=(req.getParameter("no"));
		String role="customer";
		User u =new User( name, email, password, city, contactNo, role);
		
		hs.setAttribute("status", service.signUp(u));
		//return "redirect:/book/list";
		return "/user/login";
	}

	

	

	
	
}
